import 'rc-drawer/assets/index.css';
export { default as Drawer } from 'rc-drawer';
