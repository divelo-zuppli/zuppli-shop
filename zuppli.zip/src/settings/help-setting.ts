export const help = [
  {
    id: '1',
    title: 'help-one-title',
    content: 'help-one-content',
  },
  {
    id: '2',
    title: 'help-two-title',
    content: 'help-two-content',
  },
  {
    id: '3',
    title: 'help-three-title',
    content: 'help-three-content',
  },
  {
    id: '4',
    title: 'help-four-title',
    content: 'help-four-content',
  },
  {
    id: '5',
    title: 'help-five-title',
    content: 'help-five-content',
  },
  {
    id: '6',
    title: 'help-six-title',
    content: 'help-six-content',
  },
];
