export const termsAndServices = [
  {
    id: '1',
    title: 'terms-one-title',
    description: 'terms-one-content',
  },
  {
    id: '2',
    title: 'terms-two-title',
    description: 'terms-two-content',
  },
  {
    id: '3',
    title: 'terms-three-title',
    description: 'terms-three-content',
  },
];
