export const legalSetting = [
  {
    id: '1',
    title: 'legal-one-title',
    description: 'legal-one-content',
  },
  {
    id: '2',
    title: 'legal-two-title',
    description: 'legal-two-content',
  },
  {
    id: '3',
    title: 'legal-three-title',
    description: 'legal-three-content',
  },
  {
    id: '4',
    title: 'legal-four-title',
    description: 'legal-four-content',
  },
  {
    id: '5',
    title: 'legal-five-title',
    description: 'legal-five-content',
  },
  {
    id: '6',
    title: 'legal-six-title',
    description: 'legal-six-content',
  },
  {
    id: '7',
    title: 'legal-seven-title',
    description: 'legal-seven-content',
  },
  {
    id: '8',
    title: 'legal-eight-title',
    description: 'legal-eight-content',
  },
];
