const environment = {
    GRAPHQL_ENDPOINT: process.env.REACT_APP_GRAPHQL_ENDPOINT,
    /* FIREBASE */
    FIREBASE_API_KEY: 'AIzaSyBHnvN0FLjeEud2tiV443eavJS3v3Yrg9c',
    FIREBASE_AUTH_DOMAIN: 'zuppli-dev.firebaseapp.com',
    FIREBASE_DATABASE_URL: process.env.REACT_APP_FIREBASE_DATABASE_URL,
    FIREBASE_PROJECT_ID: 'zuppli-dev',
    FIREBASE_STORAGE_BUCKET: 'zuppli-dev.appspot.com',
    FIREBASE_MESSAGING_SENDER_ID: '939863882086',
    FIREBASE_APP_ID: '1:939863882086:web:ed4639334ad85ebf1070a7',
    FIREBASE_MEASUREMENT_ID: 'G-P505JJVTN2',
  };
  
  export default environment;